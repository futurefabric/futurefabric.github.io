To view any of these prototypes, simply go into any given folder and drag and drop index.html onto a browser window.

I've only checked them in Chrome/Safari, so not sure if other browsers will behave.

The folders with the -2x suffix are just the larger versions of the prototypes.